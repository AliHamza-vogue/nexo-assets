/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Lock, 
  Mail, 
  ArrowRight, 
  ShieldCheck, 
  Cpu, 
  Activity, 
  BarChart3, 
  Globe2, 
  Zap,
  ChevronRight,
  Eye,
  EyeOff,
  AlertCircle
} from 'lucide-react';

// Mocking Frappe for the preview environment
const mockFrappe = {
  call: ({ method, args, callback }: any) => {
    console.log(`Frappe Call: ${method}`, args);
    setTimeout(() => {
      if (args.usr && args.pwd) {
        callback({ message: "Logged In" });
      } else {
        callback({ message: "Invalid Login" });
      }
    }, 1500);
  }
};

const EmpireBars = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" className={className}>
    <defs>
      <linearGradient id="empire-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
        <motion.stop 
          offset="0%" 
          animate={{ stopColor: ["#40828d", "#5ba4b0", "#2d5d65", "#40828d"] }}
          transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
        />
        <motion.stop 
          offset="100%" 
          animate={{ stopColor: ["#2d5d65", "#40828d", "#5ba4b0", "#2d5d65"] }}
          transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
        />
      </linearGradient>
    </defs>
    <g fill="url(#empire-gradient)">
      <path d="M2 11L5 9V20H2V11Z" />
      <path d="M7 3L10 1V23H7V3Z" />
      <path d="M12 12L15 10V18H12V12Z" />
      <path d="M17 6L20 4V21H17V6Z" />
    </g>
  </svg>
);

export default function App() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) return;

    setIsLoading(true);
    setStatus('loading');
    setErrorMessage(null);

    const args = {
      usr: email.trim(),
      pwd: password
    };

    const frappe = (window as any).frappe || mockFrappe;

    frappe.call({
      method: "login",
      args: args,
      callback: (r: any) => {
        setIsLoading(false);
        if (r.message === "Logged In") {
          setStatus('success');
          setTimeout(() => {
            alert("Login Successful! Redirecting to /app (Simulated)");
          }, 500);
        } else {
          setStatus('error');
          setErrorMessage(r.message || "Authentication failed. Please check your credentials.");
          setTimeout(() => {
            setStatus('idle');
            setErrorMessage(null);
          }, 5000);
        }
      }
    });
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-[#0a0b0e] text-white font-sans overflow-hidden">
      
      {/* Left Side: Branding & Features */}
      <div 
        className="relative w-full md:w-1/2 lg:w-[60%] h-[40vh] md:h-screen overflow-hidden bg-cover bg-center"
        style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80&w=2070")' }}
      >
        {/* Background Video */}
        <video
          autoPlay
          muted
          loop
          playsInline
          poster="https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80&w=2070"
          className="absolute inset-0 w-full h-full object-cover"
          style={{ filter: 'brightness(0.5)' }}
        >
          <source 
            src="https://player.vimeo.com/external/459389137.sd.mp4?s=912061690186591012354c0032953282&profile_id=164&oauth2_token_id=57447761" 
            type="video/mp4" 
          />
        </video>
        {/* Overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#0a0b0e] via-[#0a0b0e]/80 to-transparent md:bg-gradient-to-b md:from-black/60 md:to-[#0a0b0e]"></div>
        
        {/* Content */}
        <div className="relative h-full flex flex-col justify-between p-8 md:p-16 z-10">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="flex items-center gap-4"
          >
            <div className="p-3 bg-accent/20 rounded-xl border border-accent/30 backdrop-blur-md">
              <EmpireBars className="w-8 h-8 text-accent" />
            </div>
            <div>
              <motion.h2 
                animate={{ color: ["#ffffff", "#40828d", "#ffffff"] }}
                transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
                className="text-3xl font-bold tracking-tighter"
              >
                NEXO 4 ERP
              </motion.h2>
              <motion.p 
                animate={{ opacity: [0.6, 1, 0.6], color: ["#5ba4b0", "#ffffff", "#5ba4b0"] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                className="text-[10px] font-mono uppercase tracking-[0.3em]"
              >
                Enterprise Intelligence
              </motion.p>
            </div>
          </motion.div>

          <div className="max-w-xl">
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="text-4xl md:text-6xl font-bold leading-[1.1] mb-4"
            >
              THE CORE OF YOUR <motion.span 
                animate={{ color: ["#40828d", "#5ba4b0", "#2d5d65", "#40828d"] }}
                transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
                className="text-accent"
              >
                EMPIRE
              </motion.span>
            </motion.h1>
            
            <motion.p
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="text-lg md:text-xl text-gray-400 mb-8 font-light tracking-wide"
            >
              <motion.span
                animate={{ color: ["#9ca3af", "#ffffff", "#9ca3af"] }}
                transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
              >
                Beyond Transactions.
              </motion.span> <motion.span 
                animate={{ color: ["#ffffff", "#40828d", "#ffffff"] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                className="font-medium"
              >
                Pure Intelligence
              </motion.span>
            </motion.p>
            
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 1, delay: 0.4 }}
              className="space-y-4"
            >
              <FeatureCard 
                icon={<BarChart3 className="w-5 h-5" />} 
                title="Real-time Analytics" 
                desc="Live downstream production data and insights."
              />
              <FeatureCard 
                icon={<Globe2 className="w-5 h-5" />} 
                title="Global Logistics" 
                desc="End-to-end supply chain visibility."
              />
              <FeatureCard 
                icon={<ShieldCheck className="w-5 h-5" />} 
                title="Secure Infrastructure" 
                desc="Enterprise-grade security standards."
              />
            </motion.div>
          </div>

          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="hidden md:block"
          >
            <motion.p 
              animate={{ color: ["#6b7280", "#40828d", "#6b7280"] }}
              transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
              className="text-sm font-mono"
            >
              © 2026 NEXO CLOUD. ALL RIGHTS RESERVED.
            </motion.p>
          </motion.div>
        </div>
      </div>

      {/* Right Side: Login Form */}
      <div className="w-full md:w-1/2 lg:w-[40%] flex items-center justify-center p-8 md:p-16 bg-[#0f1115] relative">
        {/* Subtle Background Pattern */}
        <div className="absolute inset-0 opacity-[0.03] pointer-events-none" style={{ backgroundImage: 'radial-gradient(#40828d 1px, transparent 1px)', backgroundSize: '30px 30px' }}></div>
        
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="w-full max-w-sm z-10"
        >
          <div className="mb-10">
            <h3 className="text-3xl font-bold mb-2">Welcome back</h3>
            <p className="text-gray-400 text-sm">Please authenticate to access the ERP portal.</p>
          </div>

          <form className="form-signin space-y-6" onSubmit={handleSubmit}>
            <div className="space-y-5">
              <div className="space-y-2">
                <label htmlFor="login_email" className="text-xs font-semibold text-gray-400 uppercase tracking-wider ml-1">Username / Email</label>
                <div className="relative group">
                  <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <Mail className="h-4 w-4 text-gray-500 group-focus-within:text-accent transition-colors" />
                  </div>
                  <input
                    type="text"
                    id="login_email"
                    className="block w-full pl-11 pr-4 py-3.5 bg-[#16191e] border border-[#2d323b] rounded-xl text-sm text-white placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-accent/20 focus:border-accent/50 transition-all"
                    placeholder="abc@nexo4erp.com"
                    required
                    autoFocus
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center px-1">
                  <label htmlFor="login_password" className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Password</label>
                  <a href="#" className="text-[10px] text-accent hover:text-accent/80 font-bold uppercase tracking-tighter transition-colors">Forgot password?</a>
                </div>
                <div className="relative group">
                  <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <Lock className="h-4 w-4 text-gray-500 group-focus-within:text-accent transition-colors" />
                  </div>
                  <input
                    type={showPassword ? "text" : "password"}
                    id="login_password"
                    className="block w-full pl-11 pr-12 py-3.5 bg-[#16191e] border border-[#2d323b] rounded-xl text-sm text-white placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-accent/20 focus:border-accent/50 transition-all"
                    placeholder="••••••••••••"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-4 flex items-center text-gray-500 hover:text-accent transition-colors"
                    aria-label={showPassword ? "Hide password" : "Show password"}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </button>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3 px-1">
              <input 
                type="checkbox" 
                id="remember"
                className="w-4 h-4 rounded border-[#3b424e] bg-[#16191e] accent-accent focus:ring-0 focus:ring-offset-0 cursor-pointer" 
              />
              <label htmlFor="remember" className="text-sm text-gray-400 cursor-pointer select-none hover:text-gray-300 transition-colors">Remember this session</label>
            </div>

            <AnimatePresence>
              {errorMessage && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="bg-red-500/10 border border-red-500/20 rounded-xl p-4 flex items-start gap-3"
                >
                  <AlertCircle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <p className="text-xs font-bold text-red-500 uppercase tracking-wider">Access Denied</p>
                    <p className="text-xs text-red-400/80 leading-relaxed">{errorMessage}</p>
                  </div>
                </motion.div>
              )}
              {status === 'success' && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-accent/10 border border-accent/20 rounded-xl p-4 flex items-start gap-3"
                >
                  <ShieldCheck className="w-5 h-5 text-accent shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <p className="text-xs font-bold text-accent uppercase tracking-wider">Access Granted</p>
                    <p className="text-xs text-accent/80 leading-relaxed">Authentication successful. Redirecting to secure terminal...</p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <button
              type="submit"
              disabled={isLoading || status === 'success'}
              className="w-full relative group rounded-xl transition-all duration-300 hover:shadow-[0_0_20px_rgba(64,130,141,0.4)]"
            >
              <div className={`absolute inset-0 bg-accent rounded-xl transition-transform duration-300 group-hover:scale-[1.02] ${isLoading ? 'opacity-50' : ''}`}></div>
              
              {/* Pulse Effect */}
              <motion.div
                animate={{
                  opacity: [0, 0.4, 0],
                  scale: [1, 1.1, 1.2],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeOut",
                }}
                className="absolute inset-0 bg-accent rounded-xl pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity duration-300"
              />

              <div className="relative flex items-center justify-center gap-2 py-4 px-6 text-sm font-bold text-[#0a0b0e] uppercase tracking-widest">
                {isLoading ? (
                  <>
                    <motion.div 
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                    >
                      <Cpu className="w-5 h-5" />
                    </motion.div>
                    <span>Authenticating...</span>
                  </>
                ) : status === 'success' ? (
                  <>
                    <ShieldCheck className="w-5 h-5" />
                    <span>Access Granted</span>
                  </>
                ) : (
                  <>
                    <span>Login to ERP</span>
                    <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                  </>
                )}
              </div>
            </button>
          </form>

          <div className="mt-12 pt-8 border-t border-[#2d323b] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="relative w-12 h-6 overflow-hidden bg-[#16191e]/50 rounded-md border border-[#2d323b]">
                <svg
                  viewBox="0 0 100 40"
                  className="absolute inset-0 w-full h-full"
                  preserveAspectRatio="none"
                >
                  {/* Static Grid Lines */}
                  <line x1="0" y1="20" x2="100" y2="20" stroke="#2d323b" strokeWidth="0.5" />
                  <line x1="50" y1="0" x2="50" y2="40" stroke="#2d323b" strokeWidth="0.5" />

                  {/* ECG Path */}
                  <motion.path
                    d="M 0 20 L 35 20 L 40 18 L 45 5 L 52 35 L 57 20 L 100 20"
                    fill="none"
                    stroke={status === 'error' ? '#ef4444' : status === 'success' ? '#40828d' : '#22c55e'}
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    initial={{ pathLength: 0, pathOffset: 1 }}
                    animate={{ 
                      pathLength: [0, 1, 1],
                      pathOffset: [1, 0, -1]
                    }}
                    transition={{ 
                      duration: status === 'loading' ? 1 : 3, 
                      repeat: Infinity, 
                      ease: "linear" 
                    }}
                  />
                  
                  {/* Scanning Glow */}
                  <motion.rect
                    width="20"
                    height="40"
                    fill="url(#ecg-gradient)"
                    initial={{ x: -20 }}
                    animate={{ x: 100 }}
                    transition={{ 
                      duration: status === 'loading' ? 1 : 3, 
                      repeat: Infinity, 
                      ease: "linear" 
                    }}
                  />
                  
                  <defs>
                    <linearGradient id="ecg-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                      <stop offset="0%" stopColor="transparent" />
                      <stop offset="100%" stopColor={status === 'error' ? '#ef444444' : status === 'success' ? '#40828d44' : '#22c55e44'} />
                    </linearGradient>
                  </defs>
                </svg>
              </div>
              <AnimatePresence mode="wait">
                <motion.span 
                  key={status}
                  initial={{ opacity: 0, x: -5 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 5 }}
                  transition={{ duration: 0.3 }}
                  className="text-[10px] font-mono text-gray-500 uppercase tracking-widest"
                >
                  {status === 'loading' ? 'Verifying Node...' : 
                   status === 'error' ? 'Handshake Failed' :
                   status === 'success' ? 'Session Established' :
                   'System Operational'}
                </motion.span>
              </AnimatePresence>
            </div>
            <div className="flex items-center gap-1">
              <span className="text-[10px] text-gray-600 uppercase">Powered by</span>
              <motion.span 
                animate={{ color: ["#9ca3af", "#ffffff", "#9ca3af"] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                className="text-[10px] font-bold"
              >
                NEXO 4 ERP
              </motion.span>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}

function FeatureCard({ icon, title, desc }: { icon: React.ReactNode, title: string, desc: string }) {
  return (
    <motion.div 
      whileHover={{ x: 10 }}
      className="flex items-center gap-4 p-4 bg-white/5 border border-white/10 rounded-2xl backdrop-blur-md cursor-default group transition-colors hover:bg-white/10"
    >
      <motion.div 
        animate={{ 
          backgroundColor: ["rgba(64, 130, 141, 0.1)", "rgba(91, 164, 176, 0.2)", "rgba(64, 130, 141, 0.1)"],
          color: ["#40828d", "#ffffff", "#40828d"]
        }}
        transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
        className="p-2.5 rounded-xl group-hover:bg-accent group-hover:text-[#0a0b0e] transition-colors"
      >
        {icon}
      </motion.div>
      <div>
        <h4 className="text-sm font-bold">{title}</h4>
        <p className="text-xs text-gray-400">{desc}</p>
      </div>
      <ChevronRight className="w-4 h-4 text-gray-600 ml-auto group-hover:text-accent transition-colors" />
    </motion.div>
  );
}
